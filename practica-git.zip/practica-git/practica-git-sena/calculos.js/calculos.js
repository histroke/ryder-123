const precio_base = 100;
const iva = 0.19;
export const calulartotal = (precio) => precio * (1 + iva);
