# proyecto coderider    
## CTPI - SENA  
APRENDIZ: HAROLD
FICHA: 3229426  
FECHA: 18/02/2026   
correo: haroldmauricio833@gmail.com